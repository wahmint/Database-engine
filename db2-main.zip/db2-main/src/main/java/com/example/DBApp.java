package com.example;

import java.util.Iterator;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

public class DBApp {
	public static String directoryPath;
	// set a default incase the variable is not set in the config file
	public static int MaximumNumberOFKeysInIndex = 3;
	public static int MaximumRowsCountinPage = 3;

	public DBApp() {
		init();
	}

	// this does whatever initialization you would like
	// or leave it empty if there is no code you want to
	// execute at application startup
	public void init() {
		directoryPath = System.getProperty("user.dir"); // get the current directory

		// create metadata file if it does not exist
		String metaDataPath = directoryPath + "/metaData.csv";
		if (!Files.exists(Paths.get(metaDataPath))) {
			try {
				FileWriter metaDataFile = new FileWriter(metaDataPath, false);
				metaDataFile.write("Table Name,Column Name,Column Type,ClusteringKey,IndexName,IndexType\n");
				metaDataFile.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		String directoryRecourcesPath = directoryPath + "/src/main/resources";
		// load a properties file
		Properties properties = new Properties();
		try {
			properties.load(new FileReader(directoryRecourcesPath + "/DBApp.config"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		// load the Maximum number of keys in a B+tree node
		MaximumNumberOFKeysInIndex = Integer.parseInt(properties.getProperty("MaximumNumberOFKeysInIndex"));
		// load the Maximum number of rows in a page
		MaximumRowsCountinPage = Integer.parseInt(properties.getProperty("MaximumRowsCountinPage"));

	}

	// following method checks if a table exists
	public boolean checkIfTableExists(String strTableName) {
		String csvFile = directoryPath + "/metaData.csv";
		String line;
		String csvSplitBy = ",";

		// read the csv file and check if the table exists
		try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			while ((line = br.readLine()) != null) {
				// use comma as separator
				String[] fields = line.split(csvSplitBy);
				if (fields[0].trim().equals(strTableName)) {
					return true;
				}
			}
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	// the following method checks if column exists in a table
	public boolean checkIfColumnExists(String strTableName, String strColName) {
		String csvFile = directoryPath + "/metaData.csv";
		String line;
		String csvSplitBy = ",";

		// this allows us to loop through the table and stop when we reach the next
		// table to be more efficient
		boolean loopingThroughTable = false;

		// read the csv file and check if the column exists
		try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			while ((line = br.readLine()) != null) {
				// use comma as separator
				String[] fields = line.split(csvSplitBy);
				if (fields[0].trim().equals(strTableName)) {
					loopingThroughTable = true;
					if (fields[1].trim().equals(strColName)) {
						return true;
					}
				} else if (loopingThroughTable) {
					return false;
				}
			}
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	// the following method deserialize the table
	public table loadTable(String strTableName) {
		try {
			FileInputStream fileIn = new FileInputStream(directoryPath + "/tables/" + strTableName + ".ser");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			table table = (table) in.readObject();
			in.close();
			fileIn.close();
			return table;
		} catch (IOException i) {
			i.printStackTrace();
			return null;
		} catch (ClassNotFoundException c) {
			System.out.println("table class not found");
			c.printStackTrace();
			return null;
		}
	}

	// the following method deserializes a page
	public page loadPage(String pageName) {
		try {
			FileInputStream fileIn = new FileInputStream(directoryPath + "/pages/" + pageName + ".ser");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			page page = (page) in.readObject();
			in.close();
			fileIn.close();
			return page;
		} catch (IOException i) {
			i.printStackTrace();
			return null;
		} catch (ClassNotFoundException c) {
			System.out.println("page class not found");
			c.printStackTrace();
			return null;
		}
	}

	// following method creates one table only
	// strClusteringKeyColumn is the name of the column that will be the primary
	// key and the clustering column as well. The data type of that column will
	// be passed in htblColNameType
	// htblColNameValue will have the column name as key and the data
	// type as value
	public void createTable(String strTableName,
			String strClusteringKeyColumn,
			Hashtable<String, String> htblColNameType) throws DBAppException {

		// check if the table already exists
		if (checkIfTableExists(strTableName)) {
			throw new DBAppException("Table already exists");
		}

		// create the table
		table newTable = new table(strTableName, strClusteringKeyColumn, MaximumRowsCountinPage,
				new Vector<String>(htblColNameType.keySet()));
		// create the metadata
		try (FileWriter metaDataFile = new FileWriter(directoryPath + "/metaData.csv", true)) {

			for (String colName : htblColNameType.keySet()) {
				if (htblColNameType.get(colName).equals("java.lang.Integer")
						&& htblColNameType.get(colName).equals("java.lang.Double")
						&& htblColNameType.get(colName).equals("java.lang.String")) {
					throw new DBAppException("Invalid data type");
				}
				metaDataFile.write(strTableName + "," + colName + "," + htblColNameType.get(colName) + ","
						+ (colName.equals(strClusteringKeyColumn) ? "True" : "False") + ",null,null\n");
			}
			metaDataFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		// serialize the table
		newTable.serialize();

	}

	// following method checks if a B+tree index is already created for a column in
	// a table
	public boolean checkIfIndexIsAlreadyCreated(String strTableName, String strColName) {
		String csvFile = directoryPath + "/metaData.csv";
		String line;
		String csvSplitBy = ",";

		// read the csv file and check if the index is already created
		try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			while ((line = br.readLine()) != null) {
				// use comma as separator
				String[] fields = line.split(csvSplitBy);

				// check if the table name and column name match, and if the index type is
				// B+tree or null
				if (fields[0].trim().equals(strTableName) && fields[1].trim().equals(strColName)) {
					if (fields[5].trim().equals("B+tree")) {
						return true;
					}
				}
			}
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	public type getColumnType(String strTableName, String strColName) {
		String csvFile = directoryPath + "/metaData.csv";
		String line;
		String csvSplitBy = ",";

		// read the csv file and check if the index is already created
		try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			while ((line = br.readLine()) != null) {
				// use comma as separator
				String[] fields = line.split(csvSplitBy);

				// check if the table name and column name match, and if the index type is
				// B+tree or null
				if (fields[0].trim().equals(strTableName) && fields[1].trim().equals(strColName)) {
					if (fields[2].trim().equals("java.lang.Integer")) {
						return type.Integer;
					} else if (fields[2].trim().equals("java.lang.Double")) {
						return type.Double;
					} else if (fields[2].trim().equals("java.lang.String")) {
						return type.String;
					}
				}
			}
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	// the following method deserializes a B+tree index
	public bplustree loadIndex(String strIndexName) {
		try {
			FileInputStream fileIn = new FileInputStream(directoryPath + "/indices/" + strIndexName + ".ser");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			bplustree bpt = (bplustree) in.readObject();
			in.close();
			fileIn.close();
			return bpt;
		} catch (IOException i) {
			i.printStackTrace();
			return null;
		} catch (ClassNotFoundException c) {
			System.out.println("bplustree class not found");
			c.printStackTrace();
			return null;
		}
	}

	// the following method serializes a B+tree index
	public void serializeIndex(String strIndexName, bplustree bpt) {
		try {
			FileOutputStream fileOut = new FileOutputStream(directoryPath + "/indices/" + strIndexName + ".ser");
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(bpt);
			out.close();
			fileOut.close();
		} catch (IOException i) {
			i.printStackTrace();
		}
	}

	// following method creates a B+tree index
	public void createIndex(String strTableName,
			String strColName,
			String strIndexName) throws DBAppException {
		if (!checkIfTableExists(strTableName)) {
			throw new DBAppException("Table does not exist");

		} else if (!checkIfColumnExists(strTableName, strColName)) {
			throw new DBAppException("Column does not exist in table");

		} else if (checkIfIndexIsAlreadyCreated(strTableName, strColName)) {
			throw new DBAppException("Index already created");

		} else {
			try {
				bplustree bpt = new bplustree(MaximumNumberOFKeysInIndex, getColumnType(strTableName, strColName));

				// load the table
				table table = loadTable(strTableName);
				if (table == null) {
					throw new DBAppException("Table does not exist");
				}

				// loop through the page paths in table and load them
				for (String pagePath : table.pagesFilePaths) {
					page page = loadPage(pagePath);
					if (page == null) {
						throw new DBAppException("Page does not exist");
					}
					// loop through the tuples in the page and insert the value of the column in the
					// index
					for (tuple tuple : page.tuples) {
						bpt.insert(tuple.values.get(strColName), pagePath);
					}
				}

				// serialize the B+tree
				FileOutputStream fileOut = new FileOutputStream(directoryPath + "/indices/" + strIndexName + ".ser");
				ObjectOutputStream out = new ObjectOutputStream(fileOut);
				out.writeObject(bpt);
				out.close();
				fileOut.close();

				// update the metadata
				String csvFile = directoryPath + "/metaData.csv";
				String line;
				String csvSplitBy = ",";
				StringBuffer fileContents = new StringBuffer();
				try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
					while ((line = br.readLine()) != null) {
						// use comma as separator
						String[] fields = line.split(csvSplitBy);
						if (fields[0].trim().equals(strTableName) && fields[1].trim().equals(strColName)) {
							fields[4] = strIndexName;
							fields[5] = "B+tree";
							line = String.join(",", fields);
						}
						fileContents.append(line + "\n");
					}
				}

				// Write the updated contents back to the file
				try (FileWriter writer = new FileWriter(csvFile)) {
					writer.write(fileContents.toString());
				} catch (IOException e) {
					e.printStackTrace();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// following method inserts one row only.
	// htblColNameValue must include a value for the primary key
	public void insertIntoTable(String strTableName,
			Hashtable<String, Object> htblColNameValue) throws DBAppException {
		Enumeration<String> keys = htblColNameValue.keys();
		String metaData = directoryPath + "/metaData.csv";
		table tableToUse = loadTable(strTableName);
		tuple record = new tuple(htblColNameValue);
		while (keys.hasMoreElements()) {
			String columnName = keys.nextElement();
			type expectedType = getColumnType(strTableName, columnName);
			Object columnType = htblColNameValue.get(columnName);
			if (columnType instanceof Integer && expectedType != type.Integer) {
				throw new DBAppException("Wrong data types");
			}
			if (columnType instanceof Double && expectedType != type.Double) {
				throw new DBAppException("Wrong data types");
			}
			if (columnType instanceof String && expectedType != type.String) {
				throw new DBAppException("Wrong data types");
			}
		}
		if (!findTable(metaData, strTableName)) {
			throw new DBAppException("Wrong table name");
		}
		keys = htblColNameValue.keys();
		while (keys.hasMoreElements()) {
			String key = keys.nextElement();
			if (isClusteringKeySet(metaData, strTableName, key)) {
				String clusteringKey = key;
				if (!isIndexNameNull(metaData, strTableName, clusteringKey)) {
					if (isPageFilesArrayEmpty(System.getProperty("user.dir") + "/tables/" + strTableName + ".ser")) {
						page pageToBeInserted = tableToUse.createPage();
						pageToBeInserted.insertIntoPage(htblColNameValue);
						pageToBeInserted.serialize();
						tableToUse.serialize();
						String indexName = DBApp.getIndexName(strTableName, key);
						bplustree tree = loadIndex(indexName);
						tree.insert(htblColNameValue.get(clusteringKey), strTableName + "1");
						serializeIndex(indexName, tree);

					} else {
						String indexName = DBApp.getIndexName(strTableName, key);
						bplustree tree = loadIndex(indexName);
						String boundingPages = tree.findBoundingPages(htblColNameValue.get(clusteringKey));
						String[] boundingPagesParts = boundingPages.split(",");
						String lowerBoundPage = boundingPagesParts[0].trim();
						String upperBoundPage = "";
						if (boundingPagesParts.length < 2) {
							upperBoundPage = lowerBoundPage;
						} else {
							upperBoundPage = boundingPagesParts[1].trim();
						}
						Vector<String> pageFiles = tableToUse.getPagesFilePaths();
						String insertedPage = SortedVectorInsertion.insertWithIndex(pageFiles, record, clusteringKey,
								strTableName, lowerBoundPage, upperBoundPage);
						tree.insert(htblColNameValue.get(clusteringKey), insertedPage);
						serializeIndex(indexName, tree);
					}

				} else {
					if (isPageFilesArrayEmpty(System.getProperty("user.dir") + "/tables/" + strTableName + ".ser")) {
						page pageToBeInserted = tableToUse.createPage();
						pageToBeInserted.insertIntoPage(htblColNameValue);
						pageToBeInserted.serialize();
						tableToUse.serialize();
					} else {
						Vector<String> pageFiles = tableToUse.getPagesFilePaths();
						SortedVectorInsertion.insertIntoVectors(pageFiles, record, clusteringKey, strTableName);
					}

				}
				break;
			}
		}

		// throw new DBAppException("not implemented yet");
	}

	public static String getIndexName(String strTableName, String strColName) {
		String csvFile = directoryPath + "/metaData.csv";
		String line;
		String csvSplitBy = ",";

		// Read the CSV file and check if the index is defined for the given column
		try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			while ((line = br.readLine()) != null) {
				// Use comma as separator
				String[] fields = line.split(csvSplitBy);

				// Check if the table name and column name match, and if an index is defined
				if (fields[0].trim().equals(strTableName) && fields[1].trim().equals(strColName)) {
					String indexName = fields[4].trim();
					if (!indexName.equals("null")) {
						return indexName;
					}
				}
			}
			// No index found for the column
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static boolean findTable(String csvFile, String tableName) {
		try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			String line;
			// Skip the header line
			br.readLine();
			while ((line = br.readLine()) != null) {
				// Split the line into fields based on the CSV format
				String[] fields = line.split(",");
				// Check if the table name and column name match
				if (fields[0].trim().equals(tableName)) {
					return true;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	public static boolean isClusteringKeySet(String csvFile, String tableName, String columnName) {
		try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			String line;
			// Skip the header line
			br.readLine();
			while ((line = br.readLine()) != null) {
				// Split the line into fields based on the CSV format
				String[] fields = line.split(",");
				// Check if the table name and column name match
				if (fields[0].trim().equals(tableName) && fields[1].trim().equals(columnName)) {
					// Check if the ClusteringKey value is set to true
					String clusteringKey = fields[3].trim(); // Assuming ClusteringKey is at index 3
					return clusteringKey.equalsIgnoreCase("True");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		// Return false if the column with the specified table and column names is not
		// found
		return false;
	}

	public static boolean isIndexNameNull(String csvFile, String tableName, String columnName) {
		try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			String line;
			// Skip the header line
			br.readLine();
			while ((line = br.readLine()) != null) {
				// Split the line into fields based on the CSV format
				String[] fields = line.split(",");
				// Check if the table name and column name match
				if (fields[0].trim().equals(tableName) && fields[1].trim().equals(columnName)) {
					// Check if the IndexName value is null
					String indexName = fields[4].trim(); // Assuming IndexName is at index 4
					return indexName.equalsIgnoreCase("null");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		// Return false if the column with the specified table and column names is not
		// found
		return false;
	}

	public static boolean isPageFilesArrayEmpty(String fileName) {
		try {
			// Deserialize the Table object
			FileInputStream fileIn = new FileInputStream(fileName);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			table table = (table) in.readObject();
			in.close();
			fileIn.close();

			Vector<String> pageFiles = table.getPagesFilePaths();
			return pageFiles.isEmpty();
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
			// In case of an exception, return false
			return false;
		}
	}

	// following method updates one row only
	// htblColNameValue holds the key and new value
	// htblColNameValue will not include clustering key as column name
	// strClusteringKeyValue is the value to look for to find the row to update.
	public void updateTable(String strTableName,
			String strClusteringKeyValue,
			Hashtable<String, Object> htblColNameValue) throws DBAppException {

		throw new DBAppException("not implemented yet");
	}

	// following method could be used to delete one or more rows.
	// htblColNameValue holds the key and value. This will be used in search
	// to identify which rows/tuples to delete.
	// htblColNameValue enteries are ANDED together
	public void deleteFromTable(String strTableName,
			Hashtable<String, Object> htblColNameValue) throws DBAppException {

		throw new DBAppException("not implemented yet");
	}

	public Iterator selectFromTable(SQLTerm[] arrSQLTerms,
			String[] strarrOperators) throws DBAppException {

		return null;
	}

	public static void clearFile(String filePath) {
		try (FileWriter writer = new FileWriter(filePath, false)) {
			// Writing nothing to the file to clear its content
			System.out.println("CSV file cleared successfully.");
		} catch (IOException e) {
			System.out.println("Failed to clear CSV file: " + e.getMessage());
		}
	}

	public static void main(String[] args) {

		try {
			String strTableName = "Student";
			DBApp dbApp = new DBApp();

			Hashtable htblColNameType = new Hashtable();
			htblColNameType.put("id", "java.lang.Integer");
			htblColNameType.put("name", "java.lang.String");
			htblColNameType.put("gpa", "java.lang.double");
			dbApp.createTable(strTableName, "id", htblColNameType);
			dbApp.createIndex(strTableName, "gpa", "gpaIndex");

			Hashtable htblColNameValue = new Hashtable();
			htblColNameValue.put("id", new Integer(2343432));
			htblColNameValue.put("name", new String("Ahmed Noor"));
			htblColNameValue.put("gpa", new Double(0.95));
			dbApp.insertIntoTable(strTableName, htblColNameValue);

			htblColNameValue.clear();
			htblColNameValue.put("id", new Integer(453455));
			htblColNameValue.put("name", new String("Ahmed Noor"));
			htblColNameValue.put("gpa", new Double(0.95));
			dbApp.insertIntoTable(strTableName, htblColNameValue);

			htblColNameValue.clear();
			htblColNameValue.put("id", new Integer(5674567));
			htblColNameValue.put("name", new String("Dalia Noor"));
			htblColNameValue.put("gpa", new Double(1.25));
			dbApp.insertIntoTable(strTableName, htblColNameValue);

			htblColNameValue.clear();
			htblColNameValue.put("id", new Integer(23498));
			htblColNameValue.put("name", new String("John Noor"));
			htblColNameValue.put("gpa", new Double(1.5));
			dbApp.insertIntoTable(strTableName, htblColNameValue);

			htblColNameValue.clear();
			htblColNameValue.put("id", new Integer(78452));
			htblColNameValue.put("name", new String("Zaky Noor"));
			htblColNameValue.put("gpa", new Double(0.88));
			dbApp.insertIntoTable(strTableName, htblColNameValue);

			SQLTerm[] arrSQLTerms;
			arrSQLTerms = new SQLTerm[2];
			arrSQLTerms[0]._strTableName = "Student";
			arrSQLTerms[0]._strColumnName = "name";
			arrSQLTerms[0]._strOperator = "=";
			arrSQLTerms[0]._objValue = "John Noor";

			arrSQLTerms[1]._strTableName = "Student";
			arrSQLTerms[1]._strColumnName = "gpa";
			arrSQLTerms[1]._strOperator = "=";
			arrSQLTerms[1]._objValue = new Double(1.5);

			String[] strarrOperators = new String[1];
			strarrOperators[0] = "OR";
			// select * from Student where name = "John Noor" or gpa = 1.5;
			Iterator resultSet = dbApp.selectFromTable(arrSQLTerms, strarrOperators);
		} catch (Exception exp) {
			exp.printStackTrace();
		}
	}

}