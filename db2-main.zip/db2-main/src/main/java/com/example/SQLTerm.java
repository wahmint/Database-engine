package com.example;

import java.util.ArrayList;

/** * @author Wael Abouelsaadat */

public class SQLTerm {

    public String _strTableName, _strColumnName, _strOperator;
    public Object _objValue;

    public SQLTerm(String tableName, String columnName, String operator, Object value) {
        _strTableName = tableName;
        _strColumnName = columnName;
        _strOperator = operator;
        _objValue = value;
    }

    public boolean eval(tuple tuple, String _strOperator, Object conditionValue) {
        // Check if the tuple is not null
        if (tuple == null) {
            return false;
        }
        // Get the value of the specified column from the tuple
        Object tupleValue = tuple.getTValue(_strColumnName);

        // Check if the column exists in the tuple
        if (tupleValue == null) {
            return false;
        }
        switch (_strOperator) {
            case "=":
                return tupleValue.equals(conditionValue);
            case "!=":
                return !tupleValue.equals(conditionValue);
            case ">":
                return compare(tupleValue, conditionValue) > 0;
            case ">=":
                return compare(tupleValue, conditionValue) >= 0;
            case "<":
                return compare(tupleValue, conditionValue) < 0;
            case "<=":
                return compare(tupleValue, conditionValue) <= 0;
            default:
                return false;
        }
    }

    private static int compare(Object tupleValue, Object conditionValue) {
        // Implement custom logic to compare values of different types
        // This method assumes that the values are comparable (e.g., both integers or
        // both strings)

        // Placeholder implementation for integers
        if (tupleValue instanceof Integer && conditionValue instanceof Integer) {
            return Integer.compare((Integer) tupleValue, (Integer) conditionValue);
        }

        // Placeholder implementation for strings
        if (tupleValue instanceof String && conditionValue instanceof String) {
            return ((String) tupleValue).compareTo((String) conditionValue);
        }

        // Add more comparisons for other data types as needed

        // Default: Comparison failed
        return 0;
    }

    public static ArrayList<tuple> binarySearch(SQLTerm query, ArrayList<tuple> table1, String column){
        ArrayList<tuple> resultList = new ArrayList<>();
        ArrayList<tuple> table = table1;

        if(query._strOperator== "=") {
        	 int low = 0;
             int high = table.size() - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            tuple tuple = table.get(mid);

            // Evaluate the tuple against the query condition
            if (!query.eval(tuple, "=", query._objValue)) {
                // If the evaluation is false, narrow down the field of search
               if(compare(tuple.getTValue(column), query._objValue) < 0)
            	   low= mid+1; 
               else
                   high= mid-1;
            }
            else {//match found
            	resultList.add(tuple);
            break;}
        }
        }
        if(query._strOperator== "!=") {
        	 int low = 0;
             int high = table.size() - 1;

            while (low <= high) {
            	 int mid = low + (high - low) / 2;
                 tuple tuple = table.get(mid);
                 
            if(query.eval(tuple, "!=", query._objValue)) {
            	//search for the equivalent tuple and remove it
              if(compare(tuple.getTValue(column), query._objValue) < 0)
              	 low= mid+1; 
              else
                 high= mid-1;
              }
              else {//match found
              	table.remove(tuple);
              	resultList=table;
              break;}
            }}
        if(query._strOperator== ">") {
        	 int low = 0;
             int high = table.size() - 1;

             while (low <= high) {

            	 int mid = low + (high - low) / 2;
                 tuple tuple = table.get(mid);
                 
            if(!query.eval(tuple, "=", query._objValue)) {
            	if(compare(tuple.getTValue(column), query._objValue) < 0)
                 	 low= mid+1; 
                 else
                    high= mid-1;
                 }
                 else {//match found
                	 for (int i = mid+1; i < table.size(); i++) {
                	        resultList.add(table.get(i));
                	    }
                	 break;
                 }
            }}
        if(query._strOperator== ">=") {
        	 int low = 0;
             int high = table.size() - 1;

             while (low <= high) {

            	 int mid = low + (high - low) / 2;
                 tuple tuple = table.get(mid);
                 
            if(!query.eval(tuple, "=", query._objValue)) {
            	if(compare(tuple.getTValue(column), query._objValue) < 0)
                 	 low= mid+1; 
                 else
                    high= mid-1;
                 }
                 else {//match found
                	 for (int i = mid; i < table.size(); i++) {
                	        resultList.add(table.get(i));
                	    }
                	 break;
                 }
            }}
        if(query._strOperator== "<") {
        	 int low = 0;
             int high = table.size() - 1;

            while (low <= high) {
            	int mid = low + (high - low) / 2;
                tuple tuple = table.get(mid);
                

                // Evaluate the tuple against the query condition
                if (!query.eval(tuple, "=", query._objValue)) {
                    // If the evaluation is false, narrow down the field of search
                   if(compare(tuple.getTValue(column), query._objValue) < 0)
                	   low= mid+1; 
                   else
                       high= mid-1;
                }
                 else {//match found
                	 resultList=table;
                	 for (int i = table.size() - 1; i >= mid; i--) {
                		    resultList.remove(i);
                		}

                 break;
                 }
            }}
        if(query._strOperator== "<=") {
        	 int low = 0;
             int high = table.size() - 1;

            while (low <= high) {
            	int mid = low + (high - low) / 2;
                tuple tuple = table.get(mid);
                

                // Evaluate the tuple against the query condition
                if (!query.eval(tuple, "=", query._objValue)) {
                    // If the evaluation is false, narrow down the field of search
                   if(compare(tuple.getTValue(column), query._objValue) < 0)
                	   low= mid+1; 
                   else
                       high= mid-1;
                }
            else {//match found
           	 resultList=table;
           	for (int i = table.size() - 1; i >= mid + 1; i--) {
           	    resultList.remove(i);
           	}

            break;
                 }
            }}
           
        return resultList;
  
}
}
