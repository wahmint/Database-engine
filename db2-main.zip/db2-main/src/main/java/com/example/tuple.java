package com.example;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.stream.Collectors;

public class tuple implements Serializable {
    Hashtable<String, Object> values;

    public tuple(Hashtable<String, Object> values) {
        this.values = values;
    }

    public Hashtable<String, Object> getValues() {
        return values;
    }

    public Object getTValue(String columnName) {
        return values.get(columnName);
    }

    @Override
    public String toString() {
        return values.values().stream()
                .map(Object::toString)
                .collect(Collectors.joining(", "));
    }
}