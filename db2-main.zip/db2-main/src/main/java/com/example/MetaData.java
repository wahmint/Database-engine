package com.example;

import java.io.*;
import java.util.*;

public class MetaData {
    private List<String> metadata;

    public MetaData() {
        metadata = new ArrayList<>();
    }

    public void addTableMetadata(String tableName, String columnName, String columnType, boolean clusteringKey, String indexName, String indexType) {
        StringBuilder metadataLine = new StringBuilder();
        metadataLine.append(tableName).append(",");
        metadataLine.append(columnName).append(",");
        metadataLine.append(columnType).append(",");
        metadataLine.append(clusteringKey ? "True" : "False").append(",");
        metadataLine.append(indexName != null ? indexName : "null").append(",");
        metadataLine.append(indexType != null ? indexType : "null");
        metadata.add(metadataLine.toString());
    }

    public void writeMetadataToFile(String filename) {
        try (PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(filename)))) {
            writer.println("Table Name,Column Name,Column Type,ClusteringKey,IndexName,IndexType");
            for (String line : metadata) {
                writer.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to check if an index name exists for a given column in a specified table
    public boolean doesIndexExistForColumn(String tableName, String columnName) {
        for (String line : metadata) {
            String[] parts = line.split(",");
            if (parts[0].equals(tableName) && parts[1].equals(columnName) && !parts[4].equals("null")) {
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        MetaData metadataManager = new MetaData();

        // Example: adding metadata for a table
        metadataManager.addTableMetadata("CityShop", "ID", "java.lang.Integer", true, "IDIndex", "B+tree");
        metadataManager.addTableMetadata("CityShop", "Name", "java.lang.String", false, null, null);
        metadataManager.addTableMetadata("CityShop", "Number", "java.lang.Integer", false, "NumberIndex", "B+tree");
        metadataManager.addTableMetadata("CityShop", "Specialization", "java.lang.String", false, "SpecIndex", "B+tree");
        metadataManager.addTableMetadata("CityShop", "Address", "java.lang.String", false, "AddrIndex", "B+tree");

        // Writing metadata to file
        metadataManager.writeMetadataToFile("metadata.csv");

        // Check if an index exists for a given column in a specified table
        System.out.println("Does index exist for column 'ID' in table 'CityShop'? " + metadataManager.doesIndexExistForColumn("CityShop", "ID"));
        System.out.println("Does index exist for column 'Name' in table 'CityShop'? " + metadataManager.doesIndexExistForColumn("CityShop", "Name"));
        System.out.println("Does index exist for column 'Number' in table 'CityShop'? " + metadataManager.doesIndexExistForColumn("CityShop", "Number"));
        System.out.println("Does index exist for column 'Specialization' in table 'CityShop'? " + metadataManager.doesIndexExistForColumn("CityShop", "Specialization"));
        System.out.println("Does index exist for column 'Address' in table 'CityShop'? " + metadataManager.doesIndexExistForColumn("CityShop", "Address"));
    }
}
