package com.example;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Vector;
import java.util.stream.Collectors;
import java.util.Hashtable;

public class page implements Serializable {
    String pageName;
    Vector<tuple> tuples;
    int max; // maximum number of tuples in a page

    public page(int max, String pageName) {
        this.tuples = new Vector<tuple>();
        this.max = max;
        this.pageName = pageName;
    }

    public Vector<tuple> getTuples() {
        return tuples;
    }

    public boolean isFull() {
        return tuples.size() == max;
    }

    public boolean isEmpty() {
        return tuples.isEmpty();
    }

    public void insertIntoPage(Hashtable<String, Object> values) {
        tuples.add(new tuple(values));
    }

    public void deleteFromPage(int index) {
        tuples.remove(index);
    }

    public void serialize() {
        try {
            FileOutputStream fileOut = new FileOutputStream(
                    System.getProperty("user.dir") + "/pages/" + pageName + ".ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(this);
            out.close();
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public tuple getTuple(int index) throws DBAppException {
        if (index >= 0 && index < tuples.size()) {
            return tuples.get(index);
        } else {
            throw new DBAppException("Index out of bounds");
        }
    }

    @Override
    public String toString() {
        return tuples.stream()
                .map(Object::toString)
                .collect(Collectors.joining(", "));
    }
}
