package com.example;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Vector;

public class table implements Serializable {
    String name;
    String clusteringKey;
    int max; // maximum number of tuples in a page
    Vector<String> columns;
    Vector<String> pagesFilePaths;

    public table(String name, String clusteringKey, int max, Vector<String> columns) {
        this.name = name;
        this.clusteringKey = clusteringKey;
        this.max = max;
        this.pagesFilePaths = new Vector<String>();
    }

    public void addPage(String path) {
        pagesFilePaths.add(path);
    }

    public void removePage(String path) {
        pagesFilePaths.remove(path);
    }

    public Vector<String> getPagesFilePaths() {
        return pagesFilePaths;
    }

    public page createPage() {
        int pageNum = pagesFilePaths.size() + 1;
        page newPage = new page(max, name + pageNum);
        pagesFilePaths.add(newPage.pageName);
        newPage.serialize();
        this.serialize();
        return newPage;
    }

    public void serialize() {
        try {
            FileOutputStream fileOut = new FileOutputStream(
                    System.getProperty("user.dir") + "/tables/" + name + ".ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(this);
            out.close();
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
