package com.example;

import java.io.*;
import java.util.Vector;

public class VectorShift {
    public static void shiftElements(String tableName) {
        table table = loadTable(tableName);
        Vector<String> tableFiles = table.getPagesFilePaths();
        shiftElementsHelper(tableFiles, 0, tableName);
    }

    private static void shiftElementsHelper(Vector<String> tablePages, int index, String tableName) {
        if (index >= tablePages.size()) {
            return;
        }

        String pagePath = tablePages.get(index);
        page page = VectorShift.loadPage(pagePath);
        Vector<tuple> currentPageTuples = page.getTuples();
        table table = VectorShift.loadTable(tableName);
        if (currentPageTuples.size() > DBApp.MaximumRowsCountinPage) {
            if (index == tablePages.size() - 1) {
                int pageNum = table.pagesFilePaths.size() + 1;
                page newPage = new page(table.max, table.name + pageNum);
                table.pagesFilePaths.add(newPage.pageName);
                newPage.serialize();
                serialize(table);
                table.serialize();
                tablePages = table.getPagesFilePaths();
            }
            String nextVector = tablePages.get(index + 1);
            page pageInNextVector = VectorShift.loadPage(nextVector);
            Vector<tuple> pageTuplesInNextVector = pageInNextVector.getTuples();
            pageTuplesInNextVector.add(0, currentPageTuples.remove(currentPageTuples.size() - 1));
            page.serialize();
            pageInNextVector.serialize();
            table.serialize();
            pageInNextVector.serialize();
            VectorShift.serialize(table);
            shiftElementsHelper(tablePages, index + 1, tableName);
        }
        shiftElementsHelper(tablePages, index + 1, tableName);
    }

    public static void serialize(table table) {
        try {
            FileOutputStream fileOut = new FileOutputStream(
                    System.getProperty("user.dir") + "/tables/" + table.name + ".ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(table);
            out.close();
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static page loadPage(String pagePath) {
        try {
            FileInputStream fileIn = new FileInputStream(
                    System.getProperty("user.dir") + "/pages/" + pagePath + ".ser");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            page page = (page) in.readObject();
            in.close();
            fileIn.close();
            return page;
        } catch (IOException i) {
            i.printStackTrace();
            return null;
        } catch (ClassNotFoundException c) {
            System.out.println("page class not found");
            c.printStackTrace();
            return null;
        }
    }

    public static table loadTable(String strTableName) {
        try {
            FileInputStream fileIn = new FileInputStream(
                    System.getProperty("user.dir") + "/tables/" + strTableName + ".ser");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            table table = (table) in.readObject();
            in.close();
            fileIn.close();
            return table;
        } catch (IOException i) {
            i.printStackTrace();
            return null;
        } catch (ClassNotFoundException c) {
            System.out.println("table class not found");
            c.printStackTrace();
            return null;
        }
    }
}
