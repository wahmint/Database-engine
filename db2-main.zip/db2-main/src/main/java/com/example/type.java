package com.example;

public enum type {
    Integer, Double, String
}
