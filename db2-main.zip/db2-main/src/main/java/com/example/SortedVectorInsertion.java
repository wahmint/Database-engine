package com.example;

import java.io.*;
import java.util.Hashtable;
import java.util.Vector;

public class SortedVectorInsertion {

    public static void insertIntoVectors(Vector<String> tableFiles, tuple recordToBeInserted,String clusteringKeyColumn,
                                         String tableName) {
        int insertionIndex = -1;
        boolean inserted = false;
        Hashtable<String,Object> recordToBeInsertedHash = recordToBeInserted.getValues();
        int recordToBeInsertedClusteringKey = (int)recordToBeInsertedHash.get(clusteringKeyColumn);
        table firstTable = loadTable(tableName);

        // Find the appropriate position to insert the new number
        for (String pageName : tableFiles) {
            page currentPage = SortedVectorInsertion.loadPage(pageName);
            Vector<tuple> allTuplesInsideThePage = currentPage.getTuples();
            Hashtable<String, Object> lastHash = allTuplesInsideThePage.lastElement().getValues();
            int lastClusteringKey = (int)lastHash.get(clusteringKeyColumn);
            if (allTuplesInsideThePage.isEmpty() || recordToBeInsertedClusteringKey <= lastClusteringKey|| allTuplesInsideThePage.size() < DBApp.MaximumRowsCountinPage) {
                insertionIndex = binarySearch(allTuplesInsideThePage, recordToBeInsertedClusteringKey,clusteringKeyColumn);
                allTuplesInsideThePage.add(insertionIndex,recordToBeInserted);
                inserted = true;
                currentPage.serialize();
                firstTable.serialize();

                // If the current vector exceeds the maximum length, shift elements to the next vector
                if (allTuplesInsideThePage.size() > DBApp.MaximumRowsCountinPage) {
                    VectorShift.shiftElements(tableName);
                    firstTable = loadTable(tableName);
                    firstTable.serialize();
                }
                break;
            }
        }
        if (!inserted){
            page newPage = firstTable.createPage();
            newPage.insertIntoPage(recordToBeInsertedHash);
            newPage.serialize();
            firstTable.serialize();
        }
    }

    public static String insertWithIndex(Vector<String> tableFiles,tuple recordToBeInserted,String clusteringKeyColumn,
                                       String tableName,String lowerBound,String upperBound) {
        table firstTable = loadTable(tableName);
        Boolean inserted = false;
        page lowerBoundPage = loadPage(lowerBound);
        page upperBoundPage = loadPage(upperBound);
        Vector<tuple> allTuplesInsideLowerPage = lowerBoundPage.getTuples();
        Hashtable<String, Object> recordToBeInsertedHash = recordToBeInserted.getValues();
        int recordToBeInsertedClusteringKey = (int) recordToBeInsertedHash.get(clusteringKeyColumn);
        Hashtable<String, Object> lastHash = allTuplesInsideLowerPage.lastElement().getValues();
        int lastClusteringKey = (int) lastHash.get(clusteringKeyColumn);
        if (allTuplesInsideLowerPage.isEmpty() || recordToBeInsertedClusteringKey <= lastClusteringKey ||
                allTuplesInsideLowerPage.size() < DBApp.MaximumRowsCountinPage) {
            int insertionIndex = binarySearch(allTuplesInsideLowerPage, recordToBeInsertedClusteringKey, clusteringKeyColumn);
            allTuplesInsideLowerPage.add(insertionIndex, recordToBeInserted);
            inserted = true;
            lowerBoundPage.serialize();
            // If the current vector exceeds the maximum length, shift elements to the next vector
            if (allTuplesInsideLowerPage.size() > DBApp.MaximumRowsCountinPage) {
                VectorShift.shiftElements(tableName);
                firstTable = loadTable(tableName);
                firstTable.serialize();
            }
            return lowerBound;
        }
        else{
            Vector<tuple> upperBoundPageTuples = upperBoundPage.getTuples();
            lastHash = upperBoundPageTuples.lastElement().getValues();
            lastClusteringKey = (int) lastHash.get(clusteringKeyColumn);
            if (upperBoundPageTuples.isEmpty() || recordToBeInsertedClusteringKey <= lastClusteringKey ||
                    upperBoundPageTuples.size() < DBApp.MaximumRowsCountinPage) {
                int insertionIndex = binarySearch(upperBoundPageTuples, recordToBeInsertedClusteringKey, clusteringKeyColumn);
                upperBoundPageTuples.add(insertionIndex, recordToBeInserted);
                inserted = true;
                upperBoundPage.serialize();
                if (upperBoundPageTuples.size() > DBApp.MaximumRowsCountinPage) {
                    VectorShift.shiftElements(tableName);
                    firstTable = loadTable(tableName);
                    firstTable.serialize();
                }
                return upperBound;
            }
        }
        if (!inserted){
            page newPage = firstTable.createPage();
            newPage.insertIntoPage(recordToBeInsertedHash);
            newPage.serialize();
            firstTable.serialize();
            return newPage.pageName;
        }
        return "";
    }

    // Binary search function to find insertion index
    private static int binarySearch(Vector<tuple> list, int target,String clusteringKeyColumn) {
        int left = 0;
        int right = list.size() - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            tuple tuple = list.get(mid);
            Hashtable<String,Object> hash = tuple.getValues();
            int clusteringKey = (int)hash.get(clusteringKeyColumn);
            if (clusteringKey == target) {
                return mid;
            } else if (clusteringKey < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return left;
    }

    public static type getColumnType(String strTableName, String strColName) {
        String csvFile = DBApp.directoryPath + "/metaData.csv";
        String line;
        String csvSplitBy = ",";

        // read the csv file and check if the index is already created
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            while ((line = br.readLine()) != null) {
                // use comma as separator
                String[] fields = line.split(csvSplitBy);

                // check if the table name and column name match, and if the index type is
                // B+tree or null
                if (fields[0].trim().equals(strTableName) && fields[1].trim().equals(strColName)) {
                    if (fields[2].trim().equals("java.lang.Integer")) {
                        return type.Integer;
                    } else if (fields[2].trim().equals("java.lang.Double")) {
                        return type.Double;
                    } else if (fields[2].trim().equals("java.lang.String")) {
                        return type.String;
                    }
                }
            }
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static table loadTable(String strTableName) {
        try {
            FileInputStream fileIn = new FileInputStream(DBApp.directoryPath + "/tables/" + strTableName + ".ser");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            table table = (table) in.readObject();
            in.close();
            fileIn.close();
            return table;
        } catch (IOException i) {
            i.printStackTrace();
            return null;
        } catch (ClassNotFoundException c) {
            System.out.println("table class not found");
            c.printStackTrace();
            return null;
        }
    }

    public  static page loadPage(String pagePath) {
        try {
            FileInputStream fileIn = new FileInputStream(System.getProperty("user.dir") + "/pages/" + pagePath + ".ser");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            page page = (page) in.readObject();
            in.close();
            fileIn.close();
            return page;
        } catch (IOException i) {
            i.printStackTrace();
            return null;
        } catch (ClassNotFoundException c) {
            System.out.println("page class not found");
            c.printStackTrace();
            return null;
        }
    }
}
